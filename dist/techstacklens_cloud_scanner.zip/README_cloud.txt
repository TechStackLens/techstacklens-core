TechStackLens Cloud Infrastructure Scanner
============================

This tool collects information about your cloud infrastructure (AWS, Azure, GCP)
to be uploaded to the TechStackLens application for analysis.

Requirements:
- Python 3.6+ installed
- Appropriate cloud CLI tools configured:
  - AWS CLI for scanning AWS
  - Azure CLI for scanning Azure
  - Google Cloud SDK for scanning GCP

Steps:
1. Ensure you have authenticated with your cloud provider(s)
2. For Windows users: Run the batch file run_cloud_scanner.bat
   For Linux/macOS users: Run the shell script run_cloud_scanner.sh
3. Follow the on-screen instructions
4. Upload the resulting JSON files to the TechStackLens web application

For support, contact the TechStackLens team.
