TechStackLens Cloud Infrastructure Scanner
==========================

This tool collects information about your cloud infrastructure (AWS, Azure, and/or GCP)
to be uploaded to the TechStackLens application for analysis.

Requirements:
- Python 3.6+ installed
- AWS CLI configured (for AWS scanning)
- Azure CLI configured (for Azure scanning)
- Google Cloud SDK configured (for GCP scanning)
- Appropriate permissions to read cloud resources

Usage:
1. Extract this zip file to a directory on your system
2. Make sure you have authenticated with your cloud provider(s):
   - AWS: aws configure
   - Azure: az login
   - GCP: gcloud auth login
3. Run one of the following commands:

   # Interactive guided scan:
   ./run_cloud_scanner.sh (Linux/Mac)
   run_cloud_scanner.bat (Windows)

   # Manual scan options:
   python cloud_scanner.py --scan-aws --aws-region us-east-1
   python cloud_scanner.py --scan-azure
   python cloud_scanner.py --scan-gcp --gcp-project my-project-id
   python cloud_scanner.py --scan-aws --scan-azure --scan-gcp

4. After the scan completes, find the results in the 'techstacklens_data' directory
5. Upload the 'combined_scan_results.json' file to the TechStackLens web application

Common Options:
  --aws-services SERVICES    Comma-separated list of AWS services to scan
  --azure-services SERVICES  Comma-separated list of Azure services to scan
  --gcp-services SERVICES    Comma-separated list of GCP services to scan
  --output-dir DIR           Directory to save results (default: techstacklens_data)
  --verbose, -v              Enable verbose output for debugging
  --help, -h                 Show help message

For support, contact the TechStackLens team.
