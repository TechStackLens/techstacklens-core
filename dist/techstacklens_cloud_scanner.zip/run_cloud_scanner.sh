#!/bin/bash

echo "TechStackLens Cloud Infrastructure Scanner"
echo "======================================="
echo

echo "This scanner requires that you have configured your cloud provider CLI tools:"
echo " - AWS: aws configure"
echo " - Azure: az login"
echo " - GCP: gcloud auth login"
echo

echo "Choose a cloud provider to scan:"
echo "1. AWS"
echo "2. Azure"
echo "3. Google Cloud Platform (GCP)"
echo "4. Scan all configured providers"
echo "5. Exit"
echo

read -p "Enter your choice (1-5): " choice

case $choice in
    1)
        read -p "Enter AWS region (e.g. us-east-1) or press Enter for all regions: " region
        if [ -z "$region" ]; then
            python3 cloud_scanner.py --scan-aws --verbose
        else
            python3 cloud_scanner.py --scan-aws --aws-region "$region" --verbose
        fi
        ;;
    2)
        python3 cloud_scanner.py --scan-azure --verbose
        ;;
    3)
        read -p "Enter GCP project ID or press Enter for default project: " project
        if [ -z "$project" ]; then
            python3 cloud_scanner.py --scan-gcp --verbose
        else
            python3 cloud_scanner.py --scan-gcp --gcp-project "$project" --verbose
        fi
        ;;
    4)
        python3 cloud_scanner.py --scan-aws --scan-azure --scan-gcp --verbose
        ;;
    5)
        exit 0
        ;;
    *)
        echo "Invalid choice!"
        exit 1
        ;;
esac

echo
echo "Scan complete! Results are stored in the 'techstacklens_data' directory."
echo "Please upload the 'combined_scan_results.json' file to the TechStackLens web application."
echo
