#!/bin/bash

echo "TechStackLens Cloud Infrastructure Scanner"
echo "========================================="
echo

# Check for Python
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed or not in the PATH."
    echo "Please install Python 3.6 or higher and try again."
    echo
    exit 1
fi

# Make the script executable
chmod +x cloud_scanner.py

echo "Which cloud provider(s) would you like to scan?"
echo "1. AWS"
echo "2. Azure"
echo "3. GCP"
echo "4. All available providers"
echo
read -p "Enter your choice (1-4): " CHOICE

if [ "$CHOICE" = "1" ]; then
    python3 cloud_scanner.py --scan-aws
elif [ "$CHOICE" = "2" ]; then
    python3 cloud_scanner.py --scan-azure
elif [ "$CHOICE" = "3" ]; then
    python3 cloud_scanner.py --scan-gcp
elif [ "$CHOICE" = "4" ]; then
    python3 cloud_scanner.py --scan-aws --scan-azure --scan-gcp
else
    echo "Invalid choice. Running scan for all providers..."
    python3 cloud_scanner.py --scan-aws --scan-azure --scan-gcp
fi

echo
echo "Scan complete!"
echo "Results are saved in the techstacklens_data directory."
echo "Please upload these JSON files to the TechStackLens web application."
echo
