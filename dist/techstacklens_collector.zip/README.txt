TechStackLens Collection Tool
==========================

This tool collects information about your Windows-IIS environment and network
to be uploaded to the TechStackLens application for analysis.

Requirements:
- Windows system with IIS installed (for IIS scanning)
- Python 3.6+ installed
- Administrator privileges (for accessing IIS configuration files)
- Nmap installed (optional, for better network scanning)

Usage:
1. Extract this zip file to a directory on your Windows system
2. Open a command prompt with Administrator privileges
3. Navigate to the extracted directory
4. Run one of the following commands:

   # Scan local IIS configuration:
   python collection_script.py --scan-local

   # Scan network:
   python collection_script.py --scan-network --network-range 192.168.1.0/24

   # Scan both IIS and network:
   python collection_script.py --scan-local --scan-network

5. After the scan completes, find the results in the 'techstacklens_data' directory
6. Upload the 'combined_scan_results.json' file to the TechStackLens web application

Common Options:
  --output-dir DIR     Directory to save results (default: techstacklens_data)
  --verbose, -v        Enable verbose output for debugging
  --help, -h           Show help message

For support, contact the TechStackLens team.
