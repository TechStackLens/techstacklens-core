TechStackLens LAMP Stack Scanner
==========================

This tool collects information about your LAMP stack environment (Linux, Apache, MySQL, PHP)
to be uploaded to the TechStackLens application for analysis.

Requirements:
- Linux system with Apache, MySQL/MariaDB, and/or PHP installed
- Python 3.6+ installed
- Appropriate permissions to read configuration files (root/sudo for some operations)
- Nmap installed (optional, for better network scanning)

Usage:
1. Extract this zip file to a directory on your Linux system
2. Make the shell script executable: chmod +x run_lamp_scanner.sh
3. Run one of the following commands:

   # Interactive guided scan:
   ./run_lamp_scanner.sh

   # Manual scan options:
   python lamp_scanner.py --scan-local
   python lamp_scanner.py --scan-network --network-range 192.168.1.0/24
   python lamp_scanner.py --scan-local --scan-network

4. After the scan completes, find the results in the 'techstacklens_data' directory
5. Upload the 'combined_scan_results.json' file to the TechStackLens web application

Common Options:
  --output-dir DIR     Directory to save results (default: techstacklens_data)
  --verbose, -v        Enable verbose output for debugging
  --help, -h           Show help message

For support, contact the TechStackLens team.
