#!/bin/bash

echo "TechStackLens LAMP Stack Scanner"
echo "=============================="
echo

# Check if running with sufficient privileges
if [ "$EUID" -ne 0 ]; then
    echo "WARNING: This script is not running with root privileges."
    echo "         Some features may not work correctly."
    echo "         Consider running with sudo for better results."
    echo
    read -p "Press Enter to continue anyway, or Ctrl+C to exit and restart with sudo..." 
fi

echo "Choose a scan type:"
echo "1. Scan local LAMP configuration"
echo "2. Scan network"
echo "3. Scan both LAMP configuration and network"
echo "4. Exit"
echo

read -p "Enter your choice (1-4): " choice

case $choice in
    1)
        python3 lamp_scanner.py --scan-local --verbose
        ;;
    2)
        read -p "Enter network range to scan (e.g. 192.168.1.0/24): " network
        python3 lamp_scanner.py --scan-network --network-range "$network" --verbose
        ;;
    3)
        read -p "Enter network range to scan (e.g. 192.168.1.0/24): " network
        python3 lamp_scanner.py --scan-local --scan-network --network-range "$network" --verbose
        ;;
    4)
        exit 0
        ;;
    *)
        echo "Invalid choice!"
        exit 1
        ;;
esac

echo
echo "Scan complete! Results are stored in the 'techstacklens_data' directory."
echo "Please upload the 'combined_scan_results.json' file to the TechStackLens web application."
echo
