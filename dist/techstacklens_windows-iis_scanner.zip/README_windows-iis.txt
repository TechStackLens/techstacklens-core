TechStackLens Windows IIS Scanner
============================

This tool collects information about your Windows-IIS environment and network
to be uploaded to the TechStackLens application for analysis.

Requirements:
- Windows system with IIS installed (for IIS scanning)
- Python 3.6+ installed

Steps:
1. Run the batch file run_windows_scanner.bat
2. Follow the on-screen instructions
3. Upload the resulting JSON files to the TechStackLens web application

For support, contact the TechStackLens team.
