TechStackLens XAMPP Stack Scanner
============================

This tool collects information about your XAMPP environment (Apache, MySQL, PHP, Perl)
on either Windows or Linux systems, including detection of ELT/ETL components.

Requirements:
- Windows or Linux system with XAMPP installed
- Python 3.6+ installed

Steps:
1. For Windows users: Run the batch file run_xampp_scanner.bat
   For Linux/macOS users: Run the shell script run_xampp_scanner.sh
2. Follow the on-screen instructions
3. Upload the resulting JSON files to the TechStackLens web application

For support, contact the TechStackLens team.
